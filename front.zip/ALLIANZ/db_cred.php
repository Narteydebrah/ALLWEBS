<?php
//Database credentials
define("DATABASE", "insurancez");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>
